package main.java.interfaces;

public interface INoteListener {
  void noteChange(INote note, boolean toSaveCurrentNote);
}
