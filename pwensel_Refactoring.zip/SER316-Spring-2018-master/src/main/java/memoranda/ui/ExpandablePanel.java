package main.java.memoranda.ui;

import java.awt.event.ActionListener;

/*$Id: ExpandablePanel.java,v 1.2 2004/01/30 12:17:41 alexeya Exp $*/
public interface ExpandablePanel {

    void AddExpandListener(ActionListener al);
}